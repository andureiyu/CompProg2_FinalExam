import java.time.LocalDate;

/**
 *
 * @author mapninora
 */
public class Student extends Person {
  
    private String course;
    private int yearLevel;
    private int semester;
    
    public Student(String id, String Firstname, String Lastname, char gender, LocalDate birthdate, String course, int yearLevel, int semester) {
        super(id, Firstname, Lastname, gender, birthdate);
        this.course = course;
        this.yearLevel = yearLevel;
        this.semester = semester;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getYearLevel() {
        return yearLevel;
    }

    public void setYearLevel(int yearLevel) {
        this.yearLevel = yearLevel;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }
    public String getCourseProgramStatus()  {
       return course + " " + yearLevel + " " + (semester == 3 ? "Summer" : String.valueOf(semester));
    }
}