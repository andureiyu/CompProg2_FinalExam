import java.time.LocalDate;

/**
 *
 * @author mapninora
 */
public class Teacher extends Person {
    
    private String specialization;
    private String status;
    
     public Teacher(String id, String firstName, String lastName, char gender, LocalDate birthdate, String specialization, String status) {
        super(id, firstName, lastName, gender, birthdate);
        this.specialization = specialization;
        this.status = status;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    // the method for getStatus
    public String getStatusString() {
        switch(status.toUpperCase()) {
            case "FULL TIME":
                return "FULL TIME";
            case "PART TIME":
                return "PART TIME";
            case "INACTIVE":
                return "INACTIVE";
            default:
                return "UNKNOWN";
        }
    }
}