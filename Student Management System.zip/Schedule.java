import java.time.*;
import java.util.ArrayList;
import java.util.*;
/**
 *
 * @author mapninora
 */
public class Schedule {
    private String id;
    private Classroom classroom;
    private Teacher teacher;
    private List<Student> students;
    private LocalDateTime start_Time;
    private LocalDateTime end_Time;
    
    public Schedule(String id, Classroom classroom, Teacher teacher, LocalDateTime start_Time, LocalDateTime end_Time) {
        this.id = id;
        this.classroom = classroom;
        this.teacher = teacher;
        this.students = new ArrayList<>();
        this.start_Time = start_Time;
        this.end_Time = end_Time;
              
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Classroom getClassroom() {
        return classroom;
    }

    public void setClassroom(Classroom classroom) {
        this.classroom = classroom;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public void addStudents(Student student) {
        students.add(student);
    }
            
    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public LocalDateTime getStart_Time() {
        return start_Time;
    }

    public void setStart_Time(LocalDateTime start_Time) {
        this.start_Time = start_Time;
    }

    public LocalDateTime getEnd_Time() {
        return end_Time;
    }

    public void setEnd_Time(LocalDateTime end_Time) {
        this.end_Time = end_Time;
    }
           
}