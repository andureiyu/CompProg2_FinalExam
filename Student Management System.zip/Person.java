import java.time.*;
import java.time.LocalDate;

/**
 *
 * @author mapninora
 */
public class Person {
    private String id;
    private String Firstname;
    private String Lastname;
    private char gender;
    private LocalDate birthdate;
    
    
    public Person(String id, String Firstname, String Lastname, char gender, LocalDate birthdate) {
        this.id = id;
        this.Firstname = Firstname;
        this.Lastname = Lastname;
        this.gender = gender;
        this.birthdate = birthdate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String Firstname) {
        this.Firstname = Firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String Lastname) {
        this.Lastname = Lastname;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public LocalDate getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(LocalDate birthdate) {
        this.birthdate = birthdate;
    }
    
    
    public int getAge() {
        return Period.between(birthdate, LocalDate.now()).getYears();
    }
    public String getFullName() {
        String prefix = (gender == 'M' || gender == 'm') ? "Mr." : "Mrs.";
        return prefix + " " + Firstname + Lastname;
    }
}
